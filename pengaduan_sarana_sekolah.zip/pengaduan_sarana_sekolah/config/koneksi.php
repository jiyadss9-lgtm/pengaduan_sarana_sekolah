<?php

class Koneksi
{
    //properti
    private $host = "sql308.infinityfree.com";
    private $username = "if0_43196628";
    private $password = "Jiyad2008";
    private $database = "if0_43196628_pengaduan_sarana_sekolah";
    //private tidak bisa di akses oleh siapapun kecuali class itu sendiri

    public $koneksi;
    //publik bisa di akses oleh siapapun

    public function __construct()
    {
        //parameter
        $this->koneksi = new mysqli(
            $this->host,
            $this->username,
            $this->password,
            $this->database
        );

        if ($this->koneksi->connect_error) {
            die("Koneksi database gagal: " . $this->koneksi->connect_error);
        }

        $this->koneksi->set_charset("utf8mb4");

        $this->pastikanKolomKelas();
    }

    // Menambah kolom `kelas` di tabel users secara otomatis jika belum ada.
    private function pastikanKolomKelas()
    {
        static $sudahDicek = false;
        if ($sudahDicek) {
            return;
        }
        $sudahDicek = true;

        try {
            $cek = $this->koneksi->query("SHOW COLUMNS FROM users LIKE 'kelas'");
            if ($cek && $cek->num_rows === 0) {
                $this->koneksi->query(
                    "ALTER TABLE users ADD COLUMN kelas varchar(30) DEFAULT NULL AFTER email"
                );
            }
        } catch (Throwable $e) {
            // Abaikan; jalankan database/migrasi_kelas.sql secara manual bila perlu.
        }
    }
}