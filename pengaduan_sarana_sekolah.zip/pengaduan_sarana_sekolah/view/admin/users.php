<!doctype html><html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Data User</title><link rel="stylesheet" href="../../asset/css/style.css?v=<?= @filemtime(__DIR__ . '/../../asset/css/style.css') ?: 1 ?>"></head>
<body class="admin-dashboard">
<aside class="admin-sidebar"><div class="admin-brand"><div class="admin-avatar"><img class="app-logo-img" src="../../asset/img/logo.png" alt="Logo"></div><strong>ADMIN SEKOLAH</strong><span>PANEL ADMINISTRATOR</span></div><nav class="admin-nav"><div class="admin-nav-title">MENU UTAMA</div><a class="" href="dashboard.php"><span>⌂</span>Dashboard</a><a class="" href="pengaduan.php"><span>▣</span>Pengaduan</a><a class="active" href="users.php"><span>♙</span>Data User</a><a class="" href="lokasi.php"><span>⌖</span>Data Lokasi</a><a class="" href="kategori.php"><span>▤</span>Data Kategori</a><a href="feedback.php"><span>★</span>Umpan Balik</a><div class="admin-nav-title">AKUN</div><a class="" href="../../controller/profilcontroller.php"><span>◉</span>Profil</a><a class="admin-logout" href="../../logout.php"><span>↪</span>Logout</a></nav></aside>
<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: ../../index.php'); exit; }
require_once __DIR__ . '/../../model/user.php';
$userModel=new User(); $users=$userModel->getAll(); $msg=$_GET['msg']??'';
?><main class="admin-main"><div class="admin-page">
<header class="admin-header"><div><p>MASTER DATA</p><h1>Data User</h1><div class="admin-page-subtitle">Tambah, ubah, dan hapus akun pengguna sekolah.</div></div><div class="admin-header-actions"><button type="button" id="themeToggle" class="admin-theme-btn" aria-label="Ganti tema" title="Ganti tema">◐</button><div class="admin-header-right"><strong><?= htmlspecialchars($_SESSION['admin_nama']??'Administrator') ?></strong><span>ADMINISTRATOR</span></div></div></header>
<?php if($msg): ?><div class="admin-alert">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
<section class="admin-panel admin-form-card"><div class="admin-toolbar"><div><h2 class="admin-panel-title">Tambah User</h2><div class="admin-page-subtitle">Gunakan nomor induk sebagai username pengguna.</div></div></div>
<form action="../../controller/adminusercontroller.php" method="post" class="admin-form-grid">
<input type="hidden" name="action" value="tambah">
<div class="admin-field"><label>Nama Lengkap</label><input name="nama_lengkap" required></div>
<div class="admin-field"><label>Nomor Induk / Username</label><input name="nomor_induk" required></div>
<div class="admin-field"><label>Email</label><input type="email" name="email" required></div>
<div class="admin-field"><label>No WhatsApp</label><input name="no_whatsapp"></div>
<div class="admin-field"><label>Role</label><select name="role"><option value="siswa">Siswa</option><option value="guru">Guru</option></select></div>
<div class="admin-field"><label>Kelas <small>(khusus siswa)</small></label><input name="kelas" maxlength="30" placeholder="Contoh: XI RPL 1"></div>
<div class="admin-field"><label>Password</label><input type="password" name="password" required></div>
<div class="full admin-form-actions"><button class="admin-primary-btn" type="submit">+ Tambah User</button></div>
</form></section>
<section class="admin-panel"><div class="admin-toolbar"><div><h2 class="admin-panel-title">Daftar User</h2></div><div class="admin-toolbar-search" style="max-width:320px">⌕ <input id="searchUser" type="search" placeholder="Cari user..."></div></div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Nama</th><th>Nomor Induk</th><th>Role</th><th>Kelas</th><th>Email</th><th>Aksi</th></tr></thead><tbody>
<?php $n=0; if($users): while($u=$users->fetch_assoc()): $n++; ?>
<tr class="user-row" data-search="<?= htmlspecialchars(strtolower(($u['nama_lengkap']??'').' '.($u['nomor_induk']??'').' '.($u['kelas']??'').' '.($u['email']??'')),ENT_QUOTES) ?>">
<td><strong><?= htmlspecialchars($u['nama_lengkap']) ?></strong></td><td><?= htmlspecialchars($u['nomor_induk']) ?></td><td><?= htmlspecialchars(strtoupper($u['role'])) ?></td><td><?= htmlspecialchars(($u['kelas']??'')!==''?$u['kelas']:'-') ?></td><td><?= htmlspecialchars($u['email']) ?></td>
<td><div class="admin-table-actions"><button type="button" class="admin-secondary-btn" onclick="toggleUser(<?= (int)$u['user_id'] ?>)">Edit</button>
<form action="../../controller/adminusercontroller.php" method="post" onsubmit="return confirm('Hapus user ini?')"><input type="hidden" name="action" value="hapus"><input type="hidden" name="user_id" value="<?= $u['user_id'] ?>"><button class="admin-danger-btn" type="submit">Hapus</button></form></div></td></tr>
<tr id="user-edit-<?= (int)$u['user_id'] ?>" style="display:none"><td colspan="6"><form action="../../controller/adminusercontroller.php" method="post" class="admin-form-grid" style="padding:10px 0"><input type="hidden" name="action" value="edit"><input type="hidden" name="user_id" value="<?= $u['user_id'] ?>">
<div class="admin-field"><label>Nama</label><input name="nama_lengkap" value="<?= htmlspecialchars($u['nama_lengkap']) ?>" required></div>
<div class="admin-field"><label>Nomor Induk</label><input name="nomor_induk" value="<?= htmlspecialchars($u['nomor_induk']) ?>" required></div>
<div class="admin-field"><label>Email</label><input type="email" name="email" value="<?= htmlspecialchars($u['email']) ?>" required></div>
<div class="admin-field"><label>No WhatsApp</label><input name="no_whatsapp" value="<?= htmlspecialchars($u['no_whatsapp']??'') ?>"></div>
<div class="admin-field"><label>Role</label><select name="role"><option value="siswa" <?= $u['role']==='siswa'?'selected':'' ?>>Siswa</option><option value="guru" <?= $u['role']==='guru'?'selected':'' ?>>Guru</option></select></div>
<div class="admin-field"><label>Kelas <small>(khusus siswa)</small></label><input name="kelas" maxlength="30" value="<?= htmlspecialchars($u['kelas']??'') ?>"></div>
<div class="admin-field"><label>Password Baru</label><input type="password" name="password" placeholder="Kosongkan jika tidak diubah"></div>
<div class="full admin-form-actions"><button class="admin-primary-btn" type="submit">Simpan Perubahan</button></div></form></td></tr>
<?php endwhile; endif; ?>
<?php if($n===0): ?><tr><td colspan="6"><div class="admin-empty">Belum ada user.</div></td></tr><?php endif; ?>
</tbody></table></div></section></div></main>
<script>
function toggleUser(id){const e=document.getElementById('user-edit-'+id);e.style.display=e.style.display==='none'?'table-row':'none';}
document.getElementById('searchUser').addEventListener('input',function(){const q=this.value.toLowerCase();document.querySelectorAll('.user-row').forEach(r=>r.style.display=r.dataset.search.includes(q)?'table-row':'none');});
</script>
<script src="../../asset/js/script.js?v=<?= @filemtime(__DIR__ . '/../../asset/js/script.js') ?: 1 ?>"></script></body></html>