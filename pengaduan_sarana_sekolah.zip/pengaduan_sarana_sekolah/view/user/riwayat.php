<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../index.php");
    exit;
}

require_once __DIR__ . '/../../model/pengaduan.php';
require_once __DIR__ . '/../../model/feedback.php';
require_once __DIR__ . '/../../model/penanganan.php';
require_once __DIR__ . '/_layout.php';

$model = new Pengaduan();
$feedbackModel = new Feedback();
$penangananModel = new Penanganan();

$result = $model->getUser((int)$_SESSION['user_id']);
$semua = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Riwayat = pengaduan yang sudah selesai atau ditolak.
$data = [];
$stats = ['total' => 0, 'selesai' => 0, 'ditolak' => 0, 'belum' => 0];

foreach ($semua as $row) {
    $key = userStatusKey($row['status'] ?? '');
    if ($key !== 'selesai' && $key !== 'ditolak') {
        continue;
    }

    $row['_key'] = $key;
    $row['_feedback'] = $key === 'selesai' ? $feedbackModel->getByPengaduan((int)$row['pengaduan_id']) : null;
    $row['_penanganan'] = $penangananModel->getByPengaduan((int)$row['pengaduan_id']);
    $data[] = $row;

    $stats['total']++;
    $stats[$key]++;
    if ($key === 'selesai' && !$row['_feedback']) {
        $stats['belum']++;
    }
}

$msg = $_GET['msg'] ?? '';
$pesan = [
    'feedback_saved'       => 'Umpan balik berhasil disimpan. Terima kasih!',
    'feedback_failed'      => 'Umpan balik gagal disimpan.',
    'feedback_not_allowed' => 'Umpan balik hanya dapat diberikan untuk pengaduan yang selesai.',
];

$filterAwal = $_GET['filter'] ?? 'semua';
if (!in_array($filterAwal, ['semua', 'selesai', 'ditolak', 'belum'], true)) {
    $filterAwal = 'semua';
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Riwayat | Pengaduan Sarana Sekolah</title>
<link rel="stylesheet" href="../../asset/css/style.css?v=<?= @filemtime(__DIR__ . '/../../asset/css/style.css') ?: 1 ?>">
</head>
<body class="admin-dashboard">

<?php renderUserSidebar('riwayat'); ?>

<main class="admin-main"><div class="admin-page">

<?php renderUserHeader('ARSIP LAPORAN', 'Riwayat', 'Pengaduan yang sudah selesai atau ditolak, lengkap dengan catatan penanganan.'); ?>

<?php if ($msg && isset($pesan[$msg])): ?>
<div class="admin-alert">✓ <?= htmlspecialchars($pesan[$msg]) ?></div>
<?php endif; ?>

<section class="admin-stats">
<div class="admin-stat"><div class="admin-stat-icon">◷</div><div><div class="admin-stat-number"><?= $stats['total'] ?></div><div class="admin-stat-label">Total Riwayat</div></div></div>
<div class="admin-stat"><div class="admin-stat-icon">✓</div><div><div class="admin-stat-number"><?= $stats['selesai'] ?></div><div class="admin-stat-label">Selesai</div></div></div>
<div class="admin-stat"><div class="admin-stat-icon">×</div><div><div class="admin-stat-number"><?= $stats['ditolak'] ?></div><div class="admin-stat-label">Ditolak</div></div></div>
<div class="admin-stat"><div class="admin-stat-icon">★</div><div><div class="admin-stat-number"><?= $stats['belum'] ?></div><div class="admin-stat-label">Belum Dinilai</div></div></div>
</section>

<section class="admin-panel">
<div class="admin-toolbar">
<div><h2 class="admin-panel-title">Riwayat Pengaduan</h2><div class="admin-page-subtitle">Beri penilaian untuk pengaduan yang sudah selesai agar layanan makin baik.</div></div>
<a class="admin-secondary-btn" href="pengaduan.php" style="text-decoration:none">← Pengaduan Aktif</a>
</div>

<div class="admin-toolbar" style="margin-top:6px">
<div class="admin-toolbar-search">⌕ <input id="searchRiwayat" type="search" placeholder="Cari judul, kategori, lokasi..."></div>
<select id="filterRiwayat" class="admin-secondary-btn" aria-label="Filter riwayat">
<option value="semua" <?= $filterAwal === 'semua' ? 'selected' : '' ?>>Semua riwayat</option>
<option value="selesai" <?= $filterAwal === 'selesai' ? 'selected' : '' ?>>Selesai</option>
<option value="ditolak" <?= $filterAwal === 'ditolak' ? 'selected' : '' ?>>Ditolak</option>
<option value="belum" <?= $filterAwal === 'belum' ? 'selected' : '' ?>>Belum dinilai</option>
</select>
</div>

<div class="admin-table-wrap"><table class="admin-table">
<thead><tr><th>Pengaduan</th><th>Kategori / Lokasi</th><th>Status</th><th>Penilaian</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($data as $row):
    $id = (int)$row['pengaduan_id'];
    $key = $row['_key'];
    $fb = $row['_feedback'];
    $ph = $row['_penanganan'];
    $belum = ($key === 'selesai' && !$fb);
    $tanggal = !empty($row['created_at']) ? date('d M Y', strtotime($row['created_at'])) : '-';
    $selesaiPada = '';
    if ($ph && !empty($ph['tanggal_selesai']) && strpos($ph['tanggal_selesai'], '0000') !== 0) {
        $selesaiPada = date('d M Y', strtotime($ph['tanggal_selesai']));
    }
    $cari = strtolower(($row['judul_pengaduan'] ?? '') . ' ' . ($row['nama_kategori'] ?? '') . ' ' . ($row['nama_ruangan'] ?? '') . ' ' . ($row['deskripsi'] ?? ''));
    $adaFoto = !empty($row['foto_bukti']) && is_file(__DIR__ . '/../../asset/uploads/bukti/' . $row['foto_bukti']);
?>
<tr class="up-row" data-id="<?= $id ?>" data-status="<?= htmlspecialchars($key) ?>" data-belum="<?= $belum ? '1' : '0' ?>" data-search="<?= htmlspecialchars($cari, ENT_QUOTES) ?>">
<td><div class="up-cell">
<?php if ($adaFoto): ?><img src="../../asset/uploads/bukti/<?= htmlspecialchars($row['foto_bukti']) ?>" alt="Bukti"><?php else: ?><span class="up-ph">📷</span><?php endif; ?>
<div><strong><?= htmlspecialchars($row['judul_pengaduan']) ?></strong><div class="admin-report-meta">Dilapor <?= htmlspecialchars($tanggal) ?></div></div>
</div></td>
<td><?= htmlspecialchars($row['nama_kategori'] ?? '-') ?><div class="admin-report-meta"><?= htmlspecialchars($row['nama_ruangan'] ?? '-') ?></div></td>
<td><span class="admin-status <?= htmlspecialchars($key) ?>"><?= htmlspecialchars(userStatusLabel($key)) ?></span><?php if ($selesaiPada !== ''): ?><div class="admin-report-meta"><?= htmlspecialchars($selesaiPada) ?></div><?php endif; ?></td>
<td>
<?php if ($fb): ?>
<span class="fb-stars"><?= userBintang($fb['rating']) ?></span><span class="fb-score"><?= (int)$fb['rating'] ?>/5</span>
<?php elseif ($belum): ?>
<span class="up-muted">Belum dinilai</span>
<?php else: ?>
<span class="up-muted">-</span>
<?php endif; ?>
</td>
<td><div class="admin-table-actions"><button type="button" class="admin-secondary-btn" onclick="toggleDetail(<?= $id ?>)"><?= $belum ? 'Detail & Nilai' : 'Detail' ?></button></div></td>
</tr>
<tr id="detail-<?= $id ?>" class="up-detail" style="display:none"><td colspan="5">
<div class="admin-panel" style="margin:8px 0;background:var(--surface-2)!important">
<div class="admin-form-grid">
<div class="full"><div class="admin-report-meta">DESKRIPSI LAPORAN</div><p><?= nl2br(htmlspecialchars($row['deskripsi'] ?? '-')) ?></p></div>
<div class="full"><div class="admin-report-meta">CATATAN PENANGANAN</div>
<?php if ($ph && !empty($ph['catatan_perbaikan'])): ?>
<p><?= nl2br(htmlspecialchars($ph['catatan_perbaikan'])) ?></p>
<?php else: ?>
<p class="up-muted"><?= $key === 'ditolak' ? 'Pengaduan ini ditolak oleh admin.' : 'Tidak ada catatan penanganan.' ?></p>
<?php endif; ?>
<?php if ($ph && !empty($ph['foto_selesai'])): ?><a href="../../asset/uploads/penanganan/<?= htmlspecialchars($ph['foto_selesai']) ?>" target="_blank" rel="noopener" style="color:var(--primary);font-weight:700">Lihat bukti selesai ↗</a><?php endif; ?>
</div>

<?php if ($fb): ?>
<div class="full"><div class="admin-report-meta">UMPAN BALIK SAYA</div>
<p><span class="fb-stars"><?= userBintang($fb['rating']) ?></span> <strong><?= (int)$fb['rating'] ?>/5</strong></p>
<p class="<?= trim((string)($fb['komentar'] ?? '')) === '' ? 'up-muted' : '' ?>"><?= trim((string)($fb['komentar'] ?? '')) === '' ? 'Tidak ada komentar.' : nl2br(htmlspecialchars($fb['komentar'])) ?></p>
</div>
<?php elseif ($belum): ?>
<div class="full"><div class="admin-report-meta">BERI UMPAN BALIK</div>
<form action="../../controller/feedbackcontroller.php" method="post" class="admin-form-grid" style="margin-top:8px">
<input type="hidden" name="pengaduan_id" value="<?= $id ?>">
<div class="admin-field"><label>Rating</label><select name="rating" required><option value="">Pilih rating</option><option value="5">5 — Sangat puas</option><option value="4">4 — Puas</option><option value="3">3 — Cukup</option><option value="2">2 — Kurang</option><option value="1">1 — Tidak puas</option></select></div>
<div class="admin-field"><label>Komentar <small>(opsional)</small></label><input type="text" name="komentar" maxlength="500" placeholder="Tulis kesanmu..."></div>
<div class="full admin-form-actions"><button class="admin-primary-btn" type="submit">Kirim Umpan Balik</button></div>
</form>
</div>
<?php endif; ?>
</div>
</div>
</td></tr>
<?php endforeach; ?>
<tr id="emptyRow" <?= $data ? 'style="display:none"' : '' ?>><td colspan="5"><div class="admin-empty" id="emptyText"><?= $data ? 'Riwayat tidak ditemukan.' : 'Belum ada riwayat. Pengaduan yang selesai atau ditolak akan muncul di sini.' ?></div></td></tr>
</tbody>
</table></div>
</section>

</div></main>

<script>
function toggleDetail(id) {
    var el = document.getElementById('detail-' + id);
    el.style.display = el.style.display === 'none' ? 'table-row' : 'none';
}

(function () {
    var search = document.getElementById('searchRiwayat');
    var filter = document.getElementById('filterRiwayat');
    var rows = Array.prototype.slice.call(document.querySelectorAll('.up-row'));
    var emptyRow = document.getElementById('emptyRow');
    var emptyText = document.getElementById('emptyText');

    function apply() {
        var q = search.value.trim().toLowerCase();
        var f = filter.value;
        var shown = 0;
        rows.forEach(function (row) {
            var okStatus = f === 'semua' || (f === 'belum' ? row.dataset.belum === '1' : row.dataset.status === f);
            var ok = okStatus && row.dataset.search.indexOf(q) !== -1;
            row.style.display = ok ? '' : 'none';
            if (!ok) {
                document.getElementById('detail-' + row.dataset.id).style.display = 'none';
            }
            if (ok) shown++;
        });
        if (rows.length > 0) {
            emptyRow.style.display = shown === 0 ? '' : 'none';
            emptyText.textContent = 'Riwayat tidak ditemukan.';
        }
    }

    search.addEventListener('input', apply);
    filter.addEventListener('change', apply);
    apply();
})();
</script>
<script src="../../asset/js/script.js?v=<?= @filemtime(__DIR__ . '/../../asset/js/script.js') ?: 1 ?>"></script>
</body>
</html>
