<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: ../index.php'); exit; }
require_once __DIR__ . '/../model/pengaduan.php';
require_once __DIR__ . '/../model/penanganan.php';
$pengaduanModel = new Pengaduan();
$penangananModel = new Penanganan();
$action = $_POST['action'] ?? '';
function goPeng($msg='success') {
    header('Location: ../view/admin/pengaduan.php?msg='.urlencode($msg)); exit;
}
function uploadPenangananFoto() {
    if (empty($_FILES['foto_selesai']['name'])) return '';
    if ($_FILES['foto_selesai']['error'] !== UPLOAD_ERR_OK) return false;
    $allowed=['image/jpeg','image/png','image/webp'];
    $mime=mime_content_type($_FILES['foto_selesai']['tmp_name']);
    if (!in_array($mime,$allowed,true) || $_FILES['foto_selesai']['size']>5*1024*1024) return false;
    $dir=__DIR__.'/../asset/uploads/penanganan/';
    if(!is_dir($dir)) mkdir($dir,0775,true);
    $ext=strtolower(pathinfo($_FILES['foto_selesai']['name'],PATHINFO_EXTENSION));
    $name=time().'_'.bin2hex(random_bytes(5)).'.'.$ext;
    return move_uploaded_file($_FILES['foto_selesai']['tmp_name'],$dir.$name)?$name:false;
}
if ($action === 'status') {
    $id=(int)($_POST['pengaduan_id']??0); $status=$_POST['status']??'';
    goPeng($pengaduanModel->updateStatus($id,$status)?'Status berhasil diperbarui.':'Gagal memperbarui status.');
}
if ($action === 'verifikasi') {
    $id=(int)($_POST['pengaduan_id']??0);
    goPeng($pengaduanModel->updateStatus($id,'pending')?'Pengaduan berhasil diverifikasi.':'Gagal memverifikasi pengaduan.');
}
if ($action === 'penanganan') {
    $id=(int)($_POST['pengaduan_id']??0); $foto=uploadPenangananFoto();
    if($foto===false) goPeng('Foto penanganan tidak valid.');
    $data=['pengaduan_id'=>$id,'admin_id'=>(int)$_SESSION['admin_id'],
        'tanggal_mulai'=>$_POST['tanggal_mulai']??date('Y-m-d'),
        'tanggal_selesai'=>($_POST['tanggal_selesai']??'') ?: null,
        'catatan_perbaikan'=>trim($_POST['catatan_perbaikan']??''),
        'foto_selesai'=>$foto,'biaya'=>(float)($_POST['biaya']??0)];
    $ok=$penangananModel->simpan($data);
    if($ok) $pengaduanModel->updateStatus($id,($_POST['status_setelah']??'diproses')==='selesai'?'selesai':'diproses');
    goPeng($ok?'Penanganan berhasil disimpan.':'Gagal menyimpan penanganan.');
}
if ($action === 'hapus') {
    $id=(int)($_POST['pengaduan_id']??0);
    goPeng($pengaduanModel->hapus($id)?'Pengaduan berhasil dihapus.':'Gagal menghapus pengaduan.');
}
goPeng();
?>