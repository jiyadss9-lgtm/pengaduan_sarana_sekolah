<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../index.php'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../model/feedback.php';
require_once __DIR__ . '/../model/pengaduan.php';

$id = (int)($_POST['pengaduan_id'] ?? 0);
$rating = (int)($_POST['rating'] ?? 0);
$komentar = trim($_POST['komentar'] ?? '');
if ($rating < 1 || $rating > 5 || $id < 1) {
    header('Location: ../view/user/riwayat.php?msg=feedback_failed'); exit;
}

$model = new Pengaduan();
$row = $model->getByIdUser($id, (int)$_SESSION['user_id']);
if (!$row || ($row['status'] ?? '') !== 'selesai') {
    header('Location: ../view/user/riwayat.php?msg=feedback_not_allowed'); exit;
}

$feedback = new Feedback();
$ok = $feedback->simpan($id, $rating, $komentar);
header('Location: ../view/user/riwayat.php?msg=' . ($ok ? 'feedback_saved' : 'feedback_failed'));
exit;
