-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2026 at 03:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pengaduan_sarana_sekolah`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `nama_admin` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `nama_admin`, `email`, `password`, `created_at`) VALUES
(1, 'Administrator', 'admin@sekolah.sch.id', 'admin123', '2026-09-17 01:03:05');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `pengaduan_id` int(11) NOT NULL,
  `rating` tinyint(4) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `komentar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `pengaduan_id`, `rating`, `komentar`, `created_at`) VALUES
(1, 1, 5, 'Respon sangat cepat dan proyektor berfungsi normal kembali. Terima kasih!', '2026-08-01 05:00:00'),
(2, 2, 4, 'Pengerjaan rapi, kursi bisa digunakan belajar lagi.', '2026-08-02 08:00:00'),
(3, 3, 5, 'Mantap langsung ditangani hari itu juga, tidak ada bocor lagi.', '2026-08-03 06:00:00'),
(4, 4, 4, 'Kunci pintu sudah berfungsi baik, terima kasih pak admin.', '2026-08-04 09:00:00'),
(5, 5, 5, 'Koneksi internet PC 05 lancar kembali untuk praktikum.', '2026-08-05 09:30:00'),
(6, 6, 5, 'AC perpus sudah dingin dan tidak ada bocor air lagi.', '2026-08-07 04:00:00'),
(7, 7, 3, 'Proses lumayan lama tapi jaring ring sudah baru.', '2026-08-08 03:00:00'),
(8, 8, 5, 'Lampu mushola terang kembali, ibadah jadi nyaman.', '2026-08-08 04:00:00'),
(9, 9, 4, 'Meja kantin tidak goyang lagi saat dipakai makan.', '2026-08-09 10:00:00'),
(10, 10, 5, 'Sound system aula suaranya kembali jernih.', '2026-08-10 08:00:00'),
(11, 11, 4, 'Proses penanganan cepat merespon pengaduan.', '2026-08-11 03:00:00'),
(12, 12, 3, 'Semoga mikroskop cepat selesai diperbaiki.', '2026-08-12 04:00:00'),
(13, 13, 5, 'Penanganan koreslet listrik langsung ditindaklanjuti cepat.', '2026-08-13 07:00:00'),
(14, 14, 2, 'Papan tulis masih agak kasar saat ditulis.', '2026-08-14 08:30:00'),
(15, 15, 4, 'Petugas ramah saat mengecek jaringan labkom.', '2026-08-15 09:00:00'),
(16, 16, 1, 'Pengaduan belum diproses sama sekali.', '2026-08-16 02:00:00'),
(17, 17, 3, 'Mohon kasur UKS segera diperbaiki.', '2026-08-17 03:30:00'),
(18, 18, 2, 'Parkiran masih basah kalau hujan deras.', '2026-08-18 04:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `kategori_id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kategori_id`, `nama_kategori`, `deskripsi`) VALUES
(1, 'Elektronik & Kelistrikan', 'Pengaduan terkait sakelar, kabel, proyektor, lampu, dan kelistrikan'),
(2, 'Mebel & Furnitur', 'Pengaduan meja, kursi, papan tulis, dan lemari kelas'),
(3, 'Fasilitas Sanitasi', 'Pengaduan keran air, toilet, wastafel, dan drainase'),
(4, 'Struktur Bangunan', 'Pengaduan atap bocor, dinding retak, keramik pecah, dan pintu rusak'),
(5, 'Jaringan & Komputer', 'Pengaduan jaringan Wi-Fi, kabel LAN, dan komputer lab'),
(6, 'Pendingin Ruangan (AC)', 'Pengaduan AC mati, bocor air, atau tidak dingin'),
(7, 'Fasilitas Olahraga', 'Pengaduan ring basket, gawang, lapangan, dan alat olahraga'),
(8, 'Keamanan & K3', 'Pengaduan CCTV, APAR, pagar sekolah, dan kuncian pintu'),
(9, 'Penerangan Luar', 'Pengaduan lampu taman, lampu lapangan, dan koridor'),
(10, 'Peralatan Laboratorium', 'Pengaduan mikroskop, tabung reaksi, dan alat peraga IPA'),
(11, 'Perpustakaan', 'Pengaduan rak buku, karpet, dan meja baca perpustakaan'),
(12, 'Kantin Sekolah', 'Pengaduan meja kantin, tempat cuci piring, dan kebersihan kantin'),
(13, 'Pengeras Suara (Sound System)', 'Pengaduan bel sekolah, speaker kelas, dan mic mushola'),
(14, 'Fasilitas Ibadah', 'Pengaduan karpet mushola, tempat wudhu, dan sajadah'),
(15, 'Taman & Lingkungan', 'Pengaduan pohon rimbun, pot bunga pecah, dan tempat sampah'),
(16, 'Ruang Kesehatan (UKS)', 'Pengaduan tempat tidur UKS, lemari obat, dan alat medis sederhana'),
(17, 'Fasilitas Parkir', 'Pengaduan kanopi parkiran, marka, dan tempat helm'),
(18, 'Peralatan Kesenian', 'Pengaduan alat musik gamelan, gitar, dan sound kesenian'),
(19, 'Perlengkapan Keberkahan/Sosial', 'Pengaduan dispenser air minum umum dan tempat cuci tangan'),
(20, 'Lain-lain', 'Pengaduan sarana umum yang tidak terakomodasi pada kategori lain');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `lokasi_id` int(11) NOT NULL,
  `nama_ruangan` varchar(100) NOT NULL,
  `gedung_blok` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`lokasi_id`, `nama_ruangan`, `gedung_blok`) VALUES
(1, 'Ruang Kelas X IPA 1', 'Gedung A Lantai 1'),
(2, 'Ruang Kelas X IPA 2', 'Gedung A Lantai 1'),
(3, 'Ruang Kelas XI IPS 1', 'Gedung A Lantai 2'),
(4, 'Ruang Kelas XII IPA 3', 'Gedung B Lantai 2'),
(5, 'Laboratorium Komputer 1', 'Gedung B Lantai 1'),
(6, 'Laboratorium Komputer 2', 'Gedung B Lantai 1'),
(7, 'Laboratorium Biologi', 'Gedung C Lantai 1'),
(8, 'Laboratorium Fisika', 'Gedung C Lantai 2'),
(9, 'Perpustakaan Utama', 'Gedung Utama Lantai 2'),
(10, 'Ruang Guru', 'Gedung Utama Lantai 1'),
(11, 'Ruang Tata Usaha (TU)', 'Gedung Utama Lantai 1'),
(12, 'Ruang UKS', 'Gedung A Lantai 1'),
(13, 'Toilet Siswa Putra', 'Gedung A Lantai 1'),
(14, 'Toilet Siswa Putri', 'Gedung A Lantai 2'),
(15, 'Toilet Guru', 'Gedung Utama Lantai 1'),
(16, 'Mushola Sekolah', 'Area Belakang Gedung C'),
(17, 'Kantin Utama', 'Area Lapangan'),
(18, 'Lapangan Basket', 'Area Olahraga Center'),
(19, 'Aula Serbaguna', 'Gedung D Lantai 3'),
(20, 'Area Parkir Kendaraan', 'Halaman Depan Sekolah');

-- --------------------------------------------------------

--
-- Table structure for table `penanganan`
--

CREATE TABLE `penanganan` (
  `penanganan_id` int(11) NOT NULL,
  `pengaduan_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `tanggal_mulai` datetime DEFAULT NULL,
  `tanggal_selesai` datetime DEFAULT NULL,
  `catatan_perbaikan` text DEFAULT NULL,
  `foto_selesai` varchar(255) DEFAULT NULL,
  `biaya` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penanganan`
--

INSERT INTO `penanganan` (`penanganan_id`, `pengaduan_id`, `admin_id`, `tanggal_mulai`, `tanggal_selesai`, `catatan_perbaikan`, `foto_selesai`, `biaya`) VALUES
(21, 26, 1, '2026-09-28 00:00:00', '0000-00-00 00:00:00', '', '', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `pengaduan`
--

CREATE TABLE `pengaduan` (
  `pengaduan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lokasi_id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `judul_pengaduan` varchar(150) NOT NULL,
  `deskripsi` text NOT NULL,
  `foto_bukti` varchar(255) DEFAULT NULL,
  `urgensi` enum('rendah','sedang','tinggi') DEFAULT 'sedang',
  `status` enum('baru','pending','diproses','selesai','ditolak','') DEFAULT 'baru',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengaduan`
--

INSERT INTO `pengaduan` (`pengaduan_id`, `user_id`, `lokasi_id`, `kategori_id`, `judul_pengaduan`, `deskripsi`, `foto_bukti`, `urgensi`, `status`, `created_at`) VALUES
(1, 1, 1, 1, 'Proyektor Berkedip', 'Proyektor di X IPA 1 berkedip terus saat pelajaran berlangsung', 'bukti_1.jpg', 'sedang', 'selesai', '2026-08-01 01:00:00'),
(2, 2, 2, 2, 'Kursi Siswa Patah', 'Ada 3 kursi siswa di X IPA 2 yang patah kakinya', 'bukti_2.jpg', 'rendah', 'selesai', '2026-08-02 02:30:00'),
(3, 3, 13, 3, 'Keran Air Bocor', 'Keran air di toilet putra terus mengalir tidak bisa ditutup rapat', 'bukti_3.jpg', 'tinggi', 'selesai', '2026-08-03 03:15:00'),
(4, 4, 3, 4, 'Pintu Kelas Susah Dikunci', 'Engsel pintu XI IPS 1 longgar dan kunci rusak', 'bukti_4.jpg', 'sedang', 'selesai', '2026-08-04 04:00:00'),
(5, 5, 5, 5, 'Kabel LAN PC 05 Putus', 'Komputer nomor 05 di Labkom 1 tidak dapat terkoneksi jaringan', 'bukti_5.jpg', 'sedang', 'selesai', '2026-08-05 06:20:00'),
(6, 6, 9, 6, 'AC Perpustakaan Bocor', 'AC di area membaca mengeluarkan tetesan air cukup deras', 'bukti_6.jpg', 'tinggi', 'selesai', '2026-08-06 07:10:00'),
(7, 7, 18, 7, 'Jaring Ring Basket Sobek', 'Jaring ring sebelah timur sudah lepas dan sobek', 'bukti_7.jpg', 'rendah', 'selesai', '2026-08-07 08:45:00'),
(8, 8, 16, 8, 'Lampu Mushola Mati', 'Lampu bagian dalam mushola mati 2 titik', 'bukti_8.jpg', 'sedang', 'selesai', '2026-08-08 00:30:00'),
(9, 9, 17, 12, 'Meja Kantin Goyang', 'Salah satu meja kayu di kantin patah alas bawahnya', 'bukti_9.jpg', 'rendah', 'selesai', '2026-08-09 05:00:00'),
(10, 10, 19, 13, 'Speaker Aula Mati Sebelah', 'Suara sound system aula hanya keluar di sisi kiri', 'bukti_10.jpg', 'sedang', 'selesai', '2026-08-10 03:00:00'),
(11, 11, 10, 6, 'AC Ruang Guru Kurang Dingin', 'AC perlu dicuci dan diisi freon di area guru matematika', 'bukti_11.jpg', 'sedang', 'diproses', '2026-08-11 01:30:00'),
(12, 12, 7, 10, 'Mikroskop Cahaya Rusak', 'Fokus mikroskop nomor 3 di Lab Biologi dol/rusak', 'bukti_12.jpg', 'tinggi', 'diproses', '2026-08-12 02:15:00'),
(13, 13, 11, 1, 'Sakelar Utama TU Korslet', 'Mengeluarkan percikan api saat dinyalakan', 'bukti_13.jpg', 'tinggi', 'diproses', '2026-08-13 04:45:00'),
(14, 14, 4, 2, 'Papan Tulis Baret', 'Papan tulis spidol di XII IPA 3 sulit dibersihkan', 'bukti_14.jpg', 'rendah', 'diproses', '2026-08-14 06:00:00'),
(15, 15, 6, 5, 'Switch Hub Labkom 2 Mati', 'Setengah dari PC di labkom 2 offline', 'bukti_15.jpg', 'tinggi', 'diproses', '2026-08-15 07:30:00'),
(16, 16, 14, 3, 'Wastafel Tersumbat', 'Air di wastafel toilet putri menggenang tidak mengalir', 'bukti_16.jpg', 'sedang', 'baru', '2026-08-16 01:10:00'),
(17, 17, 12, 16, 'Kasur UKS Robek', 'Busa kasur UKS nomor 2 terlihat dan butuh diperbaiki', 'bukti_17.jpg', 'rendah', 'baru', '2026-08-17 02:50:00'),
(18, 18, 20, 17, 'Kanopi Parkir Bocor', 'Kanopi bocor menyebabkan motor kebasahan saat hujan', 'bukti_18.jpg', 'sedang', '', '2026-08-18 03:20:00'),
(26, 26, 20, 1, 'wifi lemot', 'gugcghx', '', 'tinggi', 'diproses', '2026-09-24 05:18:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `nomor_induk` varchar(30) NOT NULL,
  `role` enum('siswa','guru','') NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `kelas` varchar(30) DEFAULT NULL,
  `no_whatsapp` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `nama_lengkap`, `nomor_induk`, `role`, `email`, `no_whatsapp`, `password`, `created_at`) VALUES
(1, 'Andi Wijaya', '20241001', 'siswa', 'andi@student.sch.id', '081234567801', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(2, 'Beringin Pratama', '20241002', 'siswa', 'beringin@student.sch.id', '081234567802', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(3, 'Cinta Laura', '20241003', 'siswa', 'cinta@student.sch.id', '081234567803', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(4, 'Deni Sumargo', '20241004', 'siswa', 'deni@student.sch.id', '081234567804', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(5, 'Erlangga Putra', '20241005', 'siswa', 'erlangga@student.sch.id', '081234567805', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(6, 'Fira Farida', '20241006', 'siswa', 'fira@student.sch.id', '081234567806', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(7, 'Gilang Dirga', '20241007', 'siswa', 'gilang@student.sch.id', '081234567807', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(8, 'Hany Rahmawati', '20241008', 'siswa', 'hany@student.sch.id', '081234567808', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(9, 'Irfan Hakim', '20241009', 'siswa', 'irfan@student.sch.id', '081234567809', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(10, 'Jessica Mila', '20241010', 'siswa', 'jessica@student.sch.id', '081234567810', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(11, 'Drs. Bambang Sudirman', '198501012010011001', 'guru', 'bambang@teacher.sch.id', '081234567811', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(12, 'Siti Aminah, M.Pd.', '198703152012022002', 'guru', 'siti.guru@teacher.sch.id', '081234567812', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(13, 'Agus Hermawan, S.Pd.', '199005202015031003', 'guru', 'agus@teacher.sch.id', '081234567813', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(14, 'Dewi Lestari, S.S.', '199208102018042004', 'guru', 'dewi@teacher.sch.id', '081234567814', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(15, 'Heri Susanto, S.Kom.', '199411252020051005', 'guru', 'heri@teacher.sch.id', '081234567815', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(16, 'Rudi Tabuti', 'STAF001', '', 'rudi@staff.sch.id', '081234567816', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(17, 'Surti Suprihatin', 'STAF002', '', 'surti@staff.sch.id', '081234567817', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(18, 'Tejo Santoso', 'STAF003', '', 'tejo@staff.sch.id', '081234567818', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(19, 'Usman Harun', 'STAF004', '', 'usman@staff.sch.id', '081234567819', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(20, 'Vina Panduwinata', 'STAF005', '', 'vina@staff.sch.id', '081234567820', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1v.3xK6E2e8f1L0V4yG9.q01Z2X3Y4Z', '2026-09-03 01:34:13'),
(23, 'jiyad surya syaputra', '0081336137', 'siswa', 'jiyadsurya3@gmail.com', '083890548505', '$2y$10$K8qEoRjxfFej4VRPPn6l3uISun6uev3h0pCvqEsUbP5n5F.Yuq1gS', '2026-09-17 00:28:30'),
(24, 'ridvi', '000033221', 'siswa', 'ridvi@gmail.com', '08213456789', '$2y$10$YbL5.rXC3mobtyxvIID8j.P1bb84B44y0gnSli4SJQFY6GfRxrC7K', '2026-09-17 00:39:08'),
(25, 'sukirman', '0000012345', 'guru', 'sucikau@gmail.com', '0812345678', '$2y$10$cwUw7pT9a2auFQAHqdk/uuy7oa6gkiGa0v.5h9M0WmicnNMU.n8eu', '2026-09-17 01:06:06'),
(26, 'rady ahmad111', '11111111', 'siswa', 'rady@gmail.com', '0812345678', '$2y$10$1cbT/Qy.I410O5niWPsAneggPK0Yh0q4Qs3jUq1fZAuerMs0NkX7O', '2026-09-21 08:58:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD UNIQUE KEY `pengaduan_id` (`pengaduan_id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`lokasi_id`);

--
-- Indexes for table `penanganan`
--
ALTER TABLE `penanganan`
  ADD PRIMARY KEY (`penanganan_id`),
  ADD UNIQUE KEY `pengaduan_id` (`pengaduan_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`pengaduan_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `lokasi_id` (`lokasi_id`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `nomor_induk` (`nomor_induk`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `lokasi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `penanganan`
--
ALTER TABLE `penanganan`
  MODIFY `penanganan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `pengaduan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`pengaduan_id`) REFERENCES `pengaduan` (`pengaduan_id`) ON DELETE CASCADE;

--
-- Constraints for table `penanganan`
--
ALTER TABLE `penanganan`
  ADD CONSTRAINT `penanganan_ibfk_1` FOREIGN KEY (`pengaduan_id`) REFERENCES `pengaduan` (`pengaduan_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `penanganan_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD CONSTRAINT `pengaduan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pengaduan_ibfk_2` FOREIGN KEY (`lokasi_id`) REFERENCES `lokasi` (`lokasi_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pengaduan_ibfk_3` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`kategori_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
