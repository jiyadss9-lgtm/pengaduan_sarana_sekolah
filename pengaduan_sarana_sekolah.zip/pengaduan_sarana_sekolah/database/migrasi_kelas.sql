-- Jalankan SEKALI di phpMyAdmin pada database yang sudah ada
-- (tidak perlu jika kamu import ulang pengaduan_sarana_sekolah.sql terbaru)
ALTER TABLE `users`
  ADD COLUMN `kelas` varchar(30) DEFAULT NULL AFTER `email`;
